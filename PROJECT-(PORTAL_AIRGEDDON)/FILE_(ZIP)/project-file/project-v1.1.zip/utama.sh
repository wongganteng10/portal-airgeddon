#!/bin/bash
# =====================================================================================
# Script  : utama.sh
# Fungsi  : Menjalankan dua proses utama:
#           1. replace-mac-portal.sh → mengganti konfigurasi portal
#           2. copy-file.sh → menyalin file dari portal ke folder Tujuan-Copy
# Penulis : IT Project
# =====================================================================================

set -e  # Hentikan script jika ada error

# -------------------------------
# Warna ANSI
# -------------------------------
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
RESET='\033[0m'

# -------------------------------
# Path Script
# -------------------------------
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_DIR="$BASE_DIR/assets/file-sh"
PORTAL_DIR="$BASE_DIR/assets/portal"
TARGET_DIR="$BASE_DIR/assets/Tujuan-Copy"

# -------------------------------
# Cek File Script
# -------------------------------
if [[ ! -f "$SCRIPT_DIR/replace-mac-portal.sh" ]]; then
    echo -e "${RED}❌ Script replace-mac-portal.sh tidak ditemukan!${RESET}"
    exit 1
fi

if [[ ! -f "$SCRIPT_DIR/copy-file.sh" ]]; then
    echo -e "${RED}❌ Script copy-file.sh tidak ditemukan!${RESET}"
    exit 1
fi

# -------------------------------
# Jalankan replace-mac-portal.sh
# -------------------------------
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "🔄  ${YELLOW}Menjalankan proses replace-mac-portal.sh...${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

bash "$SCRIPT_DIR/replace-mac-portal.sh" "$PORTAL_DIR"

echo -e "\n${GREEN}✅ Proses replace selesai.${RESET}\n"

# -------------------------------
# Jalankan copy-file.sh
# -------------------------------
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "📂  ${YELLOW}Menyalin file dari portal ke Tujuan-Copy...${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

bash "$SCRIPT_DIR/copy-file.sh" "$PORTAL_DIR" "$TARGET_DIR"

echo -e "\n${GREEN}✅ Semua file berhasil disalin ke Tujuan-Copy.${RESET}\n"
