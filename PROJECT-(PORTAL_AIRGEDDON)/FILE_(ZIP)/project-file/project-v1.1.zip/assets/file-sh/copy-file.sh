#!/bin/bash
# =====================================================================================
# Script  : copy-file.sh
# Fungsi  : Menyalin file dari folder yang dipilih user di portal ke folder tujuan.
#           - Menampilkan daftar folder portal (nama saja)
#           - Menampilkan detail folder sebelum copy
#           - Jika file sudah ada → replace otomatis
#           - Mendukung opsi otomatis (--yes / -y)
# =====================================================================================

set -o pipefail

# -----------------------------#
#  Warna Terminal
# -----------------------------#
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
MAGENTA='\033[1;35m'
BOLD='\033[1m'
RESET='\033[0m'

# -----------------------------#
#  Variabel Utama
# -----------------------------#
BASE_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
PORTAL_DIR="$BASE_DIR/assets/portal"
TARGET_DIR="$BASE_DIR/assets/Tujuan-Copy"
AUTO_COPY=0

# -----------------------------#
#  Parsing opsi
# -----------------------------#
for arg in "$@"; do
  case "$arg" in
    --yes|-y) AUTO_COPY=1 ;;
  esac
done

# -----------------------------#
#  Pastikan folder portal ada
# -----------------------------#
if [[ ! -d "$PORTAL_DIR" ]]; then
  echo -e "${RED}❌ Folder portal tidak ditemukan:${RESET} $PORTAL_DIR"
  exit 1
fi

# Pastikan folder tujuan ada
mkdir -p "$TARGET_DIR"

# -----------------------------#
#  Fungsi wrap teks panjang
# -----------------------------#
wrap_text() {
  local text="$1"
  local cols
  cols=$(tput cols)
  echo "$text" | fold -s -w "$cols"
}

# -----------------------------#
#  Fungsi menampilkan daftar folder portal
# -----------------------------#
tampilkan_daftar_folder() {
  echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "${CYAN}${BOLD}                DAFTAR FOLDER${RESET}"
  echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

  mapfile -t folders < <(find "$PORTAL_DIR" -mindepth 1 -maxdepth 1 -type d | sort)

  if [[ ${#folders[@]} -eq 0 ]]; then
    echo "❌ Tidak ada folder yang bisa dipilih."
    exit 1
  fi

  for i in "${!folders[@]}"; do
    folder_name=$(basename "${folders[$i]}")
    printf " ${YELLOW}%2d.${RESET} %s\n" "$((i + 1))" "$folder_name"
  done

  echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

# -----------------------------#
#  Fungsi menampilkan detail folder
# -----------------------------#
tampilkan_info_folder() {
  local folder="$1"
  echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "📂 ${BOLD}Informasi Folder Terpilih:${RESET}"
  echo -e "Path Lengkap   : ${CYAN}$(wrap_text "$folder")${RESET}"
  echo -e "Ukuran Total   : $(du -sh "$folder" | cut -f1)"
  echo -e "Jumlah File    : $(find "$folder" -maxdepth 1 -type f | wc -l)"
  echo -e "Jumlah Subdir  : $(find "$folder" -mindepth 1 -type d | wc -l)"
  echo -e "Terakhir Ubah  : $(stat -c '%y' "$folder" | cut -d'.' -f1)"
  echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

# -----------------------------#
#  Proses pemilihan folder
# -----------------------------#
while true; do
  tampilkan_daftar_folder

  read -p "Pilih nomor folder yang ingin disalin semua filenya: " pilihan
  [[ -z "$pilihan" ]] && { echo "⚠️  Input tidak boleh kosong."; continue; }
  [[ ! "$pilihan" =~ ^[0-9]+$ ]] && { echo "⚠️  Input harus berupa angka."; continue; }

  mapfile -t folders < <(find "$PORTAL_DIR" -mindepth 1 -maxdepth 1 -type d | sort)
  if (( pilihan < 1 || pilihan > ${#folders[@]} )); then
    echo "⚠️  Pilihan tidak valid. Masukkan angka 1..${#folders[@]}."
    continue
  fi

  SELECTED_FOLDER="${folders[$((pilihan - 1))]}"
  tampilkan_info_folder "$SELECTED_FOLDER"

  [[ "$AUTO_COPY" -eq 1 ]] && break

  read -p "Apakah pilihan ini sudah benar? (y/n): " konfirmasi
  if [[ "$konfirmasi" =~ ^[Yy]$ ]]; then
    break
  else
    echo "🔄 Kembali ke daftar folder..."
    sleep 1
  fi
done

# -----------------------------#
#  Proses penyalinan file
# -----------------------------#
echo ""
echo -e "📂 Menyalin semua file dari: ${CYAN}\"$SELECTED_FOLDER\"${RESET}"
echo -e "📂 Ke folder tujuan        : ${CYAN}\"$TARGET_DIR\"${RESET}"
echo ""

shopt -s nullglob
files=("$SELECTED_FOLDER"/*)
count=0

for file in "${files[@]}"; do
  if [[ -f "$file" ]]; then
    cp -f -- "$file" "$TARGET_DIR"/
    echo "🔄 Menyalin: $(basename "$file")"
    ((count++))
  fi
done

if (( count == 0 )); then
  echo "⚠️  Tidak ada file di \"$SELECTED_FOLDER\" untuk disalin."
else
  echo -e "✅ ${GREEN}$count file berhasil disalin ke \"$TARGET_DIR\".${RESET}"
fi

echo ""
echo -e "📄 ${BOLD}Daftar isi di \"$TARGET_DIR\":${RESET}"
tree "$TARGET_DIR" 2>/dev/null || ls -R "$TARGET_DIR"
